# GSCEventMOD
Moving Object Detection for Event-based Vision using Graph Spectral Clustering
